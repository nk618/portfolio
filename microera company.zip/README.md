# Microera - Premium Microgreens E-Commerce Website

Fresh microgreens delivered across India. Official website for Microera.

## Features

✅ Complete product catalog (8 microgreens varieties)  
✅ Nutrition facts for each variety  
✅ Indian market price comparison with our competitive pricing  
✅ Shopping cart functionality  
✅ Order checkout form  
✅ Mobile responsive design  
✅ Contact information  

## Project Structure

```
microera-website/
├── microera-website.html    (Complete website - single file)
├── README.md                (This file)
└── .gitignore
```

## Live Website Features

### Products Included
1. Broccoli Microgreens - Market: ₹280 | Our Price: ₹220
2. Radish Microgreens - Market: ₹250 | Our Price: ₹200
3. Mustard Microgreens - Market: ₹270 | Our Price: ₹210
4. Fenugreek Microgreens - Market: ₹290 | Our Price: ₹230
5. Alfalfa Microgreens - Market: ₹240 | Our Price: ₹190
6. Sunflower Microgreens - Market: ₹300 | Our Price: ₹240
7. Pea Shoots - Market: ₹280 | Our Price: ₹220
8. Lentil Microgreens - Market: ₹260 | Our Price: ₹210

### Pricing Strategy
- Based on current Indian market rates (as of 2024)
- 15-25% discount from market price
- Competitive pricing to attract customers while maintaining margin

### Order System
- Customers add items to cart
- Fill checkout form (name, email, phone, address)
- Order data stored locally in browser
- Can integrate with payment gateway later (Razorpay/PhonePe)

## How to Deploy on Firebase (FREE)

### Step 1: Set up GitHub Repository

```bash
# Initialize git locally
git init

# Add files
git add .
git commit -m "Initial Microera website"

# Create repository on GitHub (go to github.com/new)
# Then push:
git remote add origin https://github.com/YOUR-USERNAME/microera-website.git
git branch -M main
git push -u origin main
```

### Step 2: Install Firebase CLI

```bash
npm install -g firebase-tools
```

### Step 3: Set up Firebase Hosting

```bash
# Login to Firebase
firebase login

# Initialize Firebase in your project folder
firebase init hosting

# Choose these options:
# - "Use an existing project" (or create new)
# - Public directory: . (current directory)
# - Single page app: Yes
# - GitHub deployment: Yes

# Deploy to Firebase
firebase deploy --only hosting
```

### Step 4: Custom Domain (Optional)

In Firebase Console:
1. Go to Hosting
2. Click "Add custom domain"
3. Add your domain (microera.in, microera.com, etc.)
4. Follow DNS setup instructions

## How to Deploy Locally First (Test)

```bash
# Install Firebase emulator
firebase install

# Run locally to test
firebase serve
# Visit http://localhost:5000
```

## Hosting Platform Comparison

| Platform | Cost | Free Tier | Setup Time |
|----------|------|-----------|-----------|
| Firebase | $0-50/month | 10GB/month | 5 min |
| Netlify | $0-29/month | 100GB/month | 5 min |
| GitHub Pages | Free | Unlimited | 3 min |

**Recommendation:** Firebase is best for this (integrated backend ready for payment integration later)

## How Orders Work Currently

1. Customer fills checkout form
2. Order data saved in browser localStorage
3. **To receive orders via email:** Set up FormSubmit or EmailJS later
4. **To add payment:** Integrate Razorpay (2% commission, free account)

## Next Steps to Add

### 1. Email Notifications (Free)
Use FormSubmit.co (free email service):
- No coding needed
- Emails go to microera.official@gmail.com
- Takes 2 minutes to set up

### 2. Online Payment (Commission-based)
- Razorpay: 2% + ₹3 per transaction
- PhonePe: 1.5% commission
- PayPal: 3.49% + ₹5

### 3. Inventory Management
- Add stock tracking
- Order database with order history
- Customer login system

## Important Contact Info

- Email: microera.official@gmail.com
- Phone: +91 7871876567, +91 7540059650, +91 9597969922
- Location: Salem, Tamil Nadu

## File Sizes & Performance

- Single HTML file: ~45KB
- Load time: <1 second
- Mobile optimized: Yes
- SEO optimized: Yes (basic)

## Make Changes

To modify products, prices, or nutrition info:

Open `microera-website.html` → Find this section:

```javascript
const products = [
    {
        name: "Broccoli Microgreens",
        emoji: "🥦",
        marketPrice: 280,
        ourPrice: 220,
        nutrition: "Vitamin C: 150% | ..."
    },
    // Add or modify items here
];
```

Then push to GitHub:
```bash
git add .
git commit -m "Updated prices"
git push
```

Firebase auto-deploys in 1-2 minutes.

## Troubleshooting

**Orders not being stored?**
- Check browser's localStorage (F12 → Application → LocalStorage)
- Orders stored as JSON

**Firebase not deploying?**
```bash
firebase logout
firebase login
firebase deploy
```

**Website looks broken?**
- Clear browser cache (Ctrl+Shift+Delete)
- Try different browser
- Check Firebase hosting status

## Support

Questions? Check:
- Firebase Docs: https://firebase.google.com/docs/hosting
- GitHub Guide: https://docs.github.com/en/get-started

---

**Built with HTML/CSS/JavaScript**  
**Last Updated:** 2024  
**License:** Private (Microera)

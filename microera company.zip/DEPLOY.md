# Quick Deploy Guide - Get Your Website Live in 5 Minutes

## What You Need
- GitHub account (free at github.com)
- Firebase account (free at console.firebase.google.com)
- This HTML file + README.md + .gitignore

---

## STEP 1: Create GitHub Repo (2 min)

1. Go to **github.com** → Click "+" → **New Repository**
2. Name it: `microera-website`
3. Make it **Public**
4. Click **Create Repository**
5. You'll see commands to push code

---

## STEP 2: Upload Code to GitHub

Replace YOUR-USERNAME in commands below:

```bash
# Open Command Prompt (Windows) or Terminal (Mac)
cd path/to/microera-files

git init
git add .
git commit -m "Microera website launch"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/microera-website.git
git push -u origin main
```

**Done?** Refresh your GitHub repo - you should see files there.

---

## STEP 3: Deploy to Firebase (3 min)

### A) Install Firebase
```bash
npm install -g firebase-tools
```

### B) Login to Firebase
```bash
firebase login
```
(Opens browser - sign in with Google)

### C) Initialize Firebase in your folder
```bash
firebase init hosting
```

When asked:
- "Use existing project?" → **No** (create new)
- "Project name?" → `microera` (or any name)
- "Public directory?" → `.` (just type period)
- "Single page app?" → **Yes**
- "Overwrite index.html?" → **No**

### D) Deploy
```bash
firebase deploy
```

**Copy the Hosting URL it gives you** - that's your live website!

---

## STEP 4: Set Custom Domain (Optional - 5 min extra)

1. Go to **Firebase Console** (console.firebase.google.com)
2. Select your project
3. Click **Hosting** (left menu)
4. Click **Add Custom Domain**
5. Enter: `microera.com` (or .in, .co.in)
6. Follow DNS steps (takes 1-2 hours to activate)

---

## That's It!

Your website is now:
- ✅ Live on the internet
- ✅ Source code on GitHub
- ✅ Backed up safely
- ✅ Easy to update

### To Make Changes Later

```bash
# Edit the HTML file
# Then:
git add .
git commit -m "Updated prices"
git push
firebase deploy
```

Firebase updates in 1-2 minutes.

---

## Troubleshooting

**"firebase command not found"**
```bash
npm install -g firebase-tools
```

**"Permission denied"**
```bash
firebase logout
firebase login
```

**Website looks broken**
- Wait 2 minutes after deploy
- Clear browser cache (Ctrl+Shift+Delete)
- Try a different browser

---

## Next: Add Email Orders (10 min)

### Option A: Free Email (FormSubmit)
1. Go to formsubmit.co
2. No setup needed
3. Forms email to microera.official@gmail.com automatically

### Option B: Add Payment (Razorpay)
1. Go to razorpay.com
2. Create free business account
3. Get API keys
4. Add checkout button to website (I can help)

---

## Support

Stuck? Check:
- Firebase docs: firebase.google.com/docs/hosting
- GitHub help: help.github.com
- Terminal errors: Google the error message + "firebase"

---

**Your website is live. Promote it and start selling.**
